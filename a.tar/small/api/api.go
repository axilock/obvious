package api

import "fmt"

func PrintHello() {
	fmt.Println("hello")
}
